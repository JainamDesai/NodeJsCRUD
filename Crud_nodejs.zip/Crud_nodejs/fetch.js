var mysql = require('mysql');
var conn = mysql.createConnection({
	host:"localhost",
	user:"root",
	password:"jainam",
	database:"jpdesai"
});
conn.connect(function(err){
if(err) throw err;
console.log("database connected");
var sql = "select * from jpdesai.mytabledemo";
conn.query(sql,function(err,result){
	if(err) throw err;
	console.log(result);
});
});