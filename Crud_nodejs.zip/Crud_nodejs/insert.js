var mysql = require('mysql');
var conn = mysql.createConnection({
	host:"localhost",
	user:"root",
	password:"jainam",
	database:"jpdesai"
});
conn.connect(function(err){
if(err) throw err;
console.log("database connected");
var sql = "insert into mytableDemo(name,location) values('Manoj','Ahmedabad')";
conn.query(sql,function(err,result){
	if(err) throw err;
	console.log('1 row inserted');
});
});