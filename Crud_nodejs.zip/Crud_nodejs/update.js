var mysql = require('mysql');
var conn = mysql.createConnection({
	host:"localhost",
	user:"root",
	password:"jainam",
	database:"jpdesai"
});
conn.connect(function(err){
if(err) throw err;
console.log("database connected");
var sql = "update jpdesai.mytabledemo set name = 'Mehul' where location = 'Mumbai'";
conn.query(sql,function(err,result){
	if(err) throw err;
	console.log('record is updated');
});
});